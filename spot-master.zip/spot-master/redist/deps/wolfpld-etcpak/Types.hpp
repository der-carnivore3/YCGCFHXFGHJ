#ifndef __DARKRL__TYPES_HPP__
#define __DARKRL__TYPES_HPP__

#include <stdint.h>

typedef unsigned int uint;

#endif
