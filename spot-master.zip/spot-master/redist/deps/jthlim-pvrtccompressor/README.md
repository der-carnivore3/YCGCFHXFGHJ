PvrTcCompressor
===============

This was an afternoon project to determine whether crude approximations could
produce reasonable results.

~~This is *NOT* complete sourcecode. It includes enough code to show the details
of how the algorithm works.~~

~~If anyone decides to make this compile separately, send a pull request.~~

Thanks to Brendan Duncan for contributing a pull request to fill in all of the
classes and to build a simple test case. Specifically, he has contributed all of
the files that do NOT begin with PvrTc

http://roartindon.blogspot.sg/2014/08/pvr-texture-compression-exploration.html

