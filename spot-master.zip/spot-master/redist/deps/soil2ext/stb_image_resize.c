#define STB_IMAGE_RESIZE_IMPLEMENTATION
#include "stb_image_resize.h"
